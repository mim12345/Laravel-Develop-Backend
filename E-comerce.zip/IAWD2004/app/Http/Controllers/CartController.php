<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cart;
use Carbon\Carbon;
use App\Coupon;
class CartController extends Controller
{

     function cart($coupon = ''){
        if ($coupon == '') {
        	$discount =0;
        	$user_ip= $_SERVER['REMOTE_ADDR'];
        $carts=Cart::with('product')->where('user_ip',$user_ip)->get();

       // $carts =($grand_total*$discount->coupon_discount)/100;
       // $grand_total=$grand_total-$discount;
        session(['discount' => $discount]);
        return view('fontend.cart',compact('carts','discount'));
        }

        else{
        	if (Coupon::where('coupon_code',$coupon)->exists()){
        		$validity = Coupon::where('coupon_code',$coupon)->first()->coupon_validity;
        		if(Carbon::now()->format('Y-m-d') <= $validity){
        			$user_ip= $_SERVER['REMOTE_ADDR'];
                   $carts=Cart::with('product')->where('user_ip',$user_ip)->get();
                   $discount = Coupon::where('coupon_code',$coupon)->first()->coupon_discount;
                   
                   session(['discount' => $discount]);
                   return view('fontend.cart',compact('carts','discount'));
        		}
        		else{
        			return 'Expired';
        		}
        	}
        	else{
        		return 'nai';
        	}
        }

        
    }

    function SingleCartDelete($cart_id){
        $user_ip= $_SERVER['REMOTE_ADDR'];
        Cart::where('id',$cart_id)->where('user_ip',$user_ip)->delete();
    	return back()->with('CartDelete','Cart Item  Delete Successfully');
    }

    function CartUpdate(Request $request){

    	foreach ($request->cart_id as $key => $item) {
    		Cart::findOrFail($item)->update([
    			'product_quantity' => $request->product_quantity[$key],
    			'updated_at' =>Carbon::now()

    		]);
    	}

    	return 'Update';
    }
}
