<?php

namespace App\Http\Controllers;
use App\Cart;
use App\Category; 
use App\Product;
use Carbon\Carbon;
use Illuminate\Http\Request;

class FontendController extends Controller
{
    function FontendPage(){
    	$product = Product::all();

    	return view('fontend.main',compact('product'));
    }
    function SingleProduct($slug){
    	$product = product::where('slug',$slug)->first();
    	$title= $product->product_name;
        $related_product=Product::where('category_id',$product->category_id)->limit(4)->inRandomOrder()->get(); 
    	return view('fontend.single_product',compact('product','title','related_product'));

    }

    function shop(){

    	$categories = Category::orderBy('category_name','asc')->get();
        $products =Product::orderBy('product_name','asc')->get();
    	return view('fontend.shop',compact('categories','products'));
    }

    function SingleCart($product_id){

     $user_ip= $_SERVER['REMOTE_ADDR'];
     
     if (Cart::where('product_id',$product_id)->where('user_ip',$user_ip)->exists()){
         Cart::where('product_id',$product_id)->where('user_ip',$user_ip)->increment('product_quantity');
     }
    else{
        Cart::insert([

         'product_id' => $product_id,
         
         'user_ip' =>$user_ip,
        'created_at'=>Carbon::now()

        ]); 
    }



       
        return back();
    }

    
}
