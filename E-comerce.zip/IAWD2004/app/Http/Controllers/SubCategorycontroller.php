<?php

namespace App\Http\Controllers;

use App\Category;
use App\SubCategory;
use Carbon\Carbon;
use Illuminate\Http\Request;



class SubCategorycontroller extends Controller
{

  function __construct(){
    $this->middleware('verified');


   }




  function subcategory(){
    
    $categories=Category::orderBy('category_name', 'asc')->get(); 

  	return view('backend/subcategory/subcategory', compact('categories'));

  }

  function subcategorypost(Request $request){
      
      SubCategory::insert([
      	'subcategory_name' => $request->subcategory_name,
        'subcategory_id' => $request->category_id,
        'created_at' => Carbon::now(),
      ]);

  	return back()->with('success','Sub Category Add Successfully');

  }

  function subcategoryView(){
      $scategory=SubCategory::count();
      $categories=SubCategory::with('get_category')->paginate(5);

  	return view('backend/subcategory/view_subcategory' ,compact('categories','scategory'));

  }

  function subcategoryDelete($id){
      
      SubCategory::findOrFail($id)->delete();

  	return back();

  }

  function subcategoryEdit(){
      
      SubCategory::all();

  	return view('backend/subcateory');

  }

  function subcategoryUpadate(){
      
      SubCategory::all();

  	return view('backend/subcateory');

  }

  function subcategoryDeleted(){
  	 $scategory=SubCategory::onlyTrashed()->count();
    $categories=SubCategory::onlyTrashed()->paginate(5);

  	return view('backend/subcategory/deleted_subcategory',compact('categories','scategory'));
  }

  function subcategoryRestore($id){

 

   SubCategory::withTrashed()->findOrFail($id)->restore();

   return back()->with('delete','Data Restore succesfully');

  }
  function subcategoryRemove($id){

   SubCategory::withTrashed()->findOrFail($id)->forceDelete();

   return back()->with('delete','Data Remove Permanently');

  }

}
