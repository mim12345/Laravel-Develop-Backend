<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\category;
use Carbon\Carbon;
class categorycontroller extends Controller

{

   function __construct(){
    $this->middleware('verified');


   }





    function category(){
    	
    	return view('backend/category');
    }
    function categoryPost(Request $request){

     // Form Validation
    	$request->validate([
         'category_name'=>['required','min:3','max:50','unique:categories']

    	]);

     
     $cat= new Category;
     //Database field Name = Form Input Name
     $cat->category_name = $request->category_name;
     $cat->save();
     return back()->with('success','Category Added Successfully');

    // 	category::insert(['category_name'=> $request->name,
    // 		'created_at' =>Carbon::now()
    // ]);
    // 	return "ok";
    }


    function categoryView(){

     $category = Category::orderBy('category_name','asc')->paginate(5);


       return view('backend/view_category',compact('category'));
    }

    function categoryDelete($id){
        // finOrFail function work only for ID
        //Other where function/like slug find or delete

        category::findOrFail($id)->delete();
        //category::where('id','$id')->delete();

        return back()->with('delete','Category Delete Successfully');
    }
    
    function categoryEdit($id){

         $category= Category::findOrFail($id);
        return view('backend/edit_category' ,compact('category'));


    }

    function categoryUpadate(Request $request){
        $id=$request->category_id;
        Category::findOrFail($id)->update([
         'category_name' =>$request->category_name,
        ]);
        
        return redirect('/view-category-list')->with('update','Category Updated Successfully');

}

}
