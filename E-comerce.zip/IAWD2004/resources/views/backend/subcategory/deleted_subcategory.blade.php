@extends('layouts.app')
@section('content')
<div class="container sm-2">
 <div class="row">
  <div class="col-10 offset-1 ">
    <div class="card bg-light mb-3" style=" margin-top: 50px;">
  <div class="card-header bg-primary text-light  text-center" style="font-family: Times New Roman, Times, serif;"><h4> Deleted Sub Category View (Total-{{$scategory}})</h4></div>
  <div class="card-body">

    @if(session('delete'))
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <strong>Oops!</strong> {{ session('delete') }}
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <hr>
    @endif
     
     <table class="table table-bordered">
  <thead>
    <tr>
        <th scope="col">SL</th>
        <th scope="col">Sub Category Name</th>
        <th scope="col"> Category Name</th>
        <th scope="col">Created_at</th>
        <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
        @forelse($categories as $key=> $subcategory)

          <tr>
              <th scope="row">{{ $categories->firstItem() + $key }}</th>
              <td>{{ $subcategory->subcategory_name ?  : "N/A "}}</td>
              <td>{{ $subcategory->subcategory_id ?  : "N/A "}}</td>
              {{-- <!-- <td>{{ $subcategory->category_name ?? "N/A "}}</td> -- --}}>
              <td>{{ $subcategory->created_at == '' ? 'N/A'  : $subcategory->created_at->format('D-M-Y')  .'('. $subcategory->created_at->diffForHumans() .')'}}</td>
              <td> 
              <a class="btn btn-outline-success" href="{{ url('/restore-subcategory')}}/{{$subcategory->id }}" >Restore</a> 
              <a class="btn btn-outline-danger" href="{{ url('/permanent-remove-subcategory')}}/{{$subcategory->id }}">Remove</a> 

            </td>
          </tr>
          @empty
          <tr class="text-center">
              <td colspan="10"><strong>No Data Available</strong></td>
          </tr>
        @endforelse
  </tbody>
</table>
{{ $categories->links() }}
   
  </div>
</div>
    
  </div>   
 </div> 
</div>

@endsection
