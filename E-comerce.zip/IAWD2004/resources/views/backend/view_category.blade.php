@extends('layouts.app')
@section('content')
<div class="container sm-2">
 <div class="row">
  <div class="col-8 offset-2 ">
    <div class="card bg-light mb-3" style=" margin-top: 50px;">
  <div class="card-header bg-primary text-light  text-center" style="font-family: Times New Roman, Times, serif;"><h4> Category View</h4></div>
  <div class="card-body">

    @if(session('delete'))
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <strong>Oops!</strong> {{ session('delete') }}
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <hr>
    @endif
     
     <table class="table table-bordered">
  <thead>
    <tr>
        <th scope="col">SL</th>
        <th scope="col">Name</th>
        <th scope="col">Created_at</th>
        <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
        @foreach($category as $key=> $cat)
          <tr>
              <th scope="row">{{ $category->firstItem() + $key }}</th>
              <td>{{ $cat->category_name ?  : "N/A "}}</td>
              <!-- <td>{{ $cat->category_name ?? "N/A "}}</td> -->
              <td>{{ $cat->created_at == '' ? 'N/A'  : $cat->created_at->format('D-M-Y')  .'('. $cat->created_at->diffForHumans() .')'}}</td>
              <td> 
              <a class="btn btn-outline-success" href="{{ url('/edit-category')}}/{{$cat->id }}" >Edit</a> 
              <a class="btn btn-outline-danger" href="{{ url('/delete-category')}}/{{$cat->id }}">Delete</a> 

            </td>
          </tr>
        @endforeach
  </tbody>
</table>
{{ $category->links() }}
   
  </div>
</div>
    
  </div>   
 </div> 
</div>

@endsection
