@extends('backend.master')
@section('content')
<div class="content">
 <div class="container-fluid ">
 <div class="row">
  <div class="col-12  ">
    <div class="card bg-light mb-3" style=" margin-top: 50px;">
  <div class="card-header bg-primary text-light  text-center" style="font-family: Times New Roman, Times, serif;"><h4> Product View {{-- (Total-{{ $category_name }}) --}}</h4></div>
  <div class="card-body">
    @if(session('delete'))
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <strong>Oops!</strong> {{ session('delete') }}
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <hr>
    @endif
     
     <table class="table table-bordered">
  <thead>
    <tr>
        <th scope="col">SL</th>
        <th scope="col">Product Name</th>
        <th scope="col"> Category </th>
        
        <th scope="col"> Sub-Category </th>
        <th scope="col"> Price </th>
        <th scope="col"> Quantity </th>
       
       
         <th scope="col"> Image </th>
          <th scope="col">Created_at</th>
        <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
        @foreach($products as $key=> $item)
          <tr>
              <th scope="row">{{ $products->firstItem() + $key }}</th>
              <td>{{ $item->product_name ?  : "N/A "}}</td>
              <td>{{ $item->get_category->category_name }}</td>
              <td>{{ $item->get_subcategory->subcategory_name }}</td>
              <td>{{ $item->product_price}}</td>
              
              <td>{{ $item->product_quantitiy}}</td>
              <td> <img src="{{ url('/img/thumbnail/').'/'.$item->product_thumbnail}}" width="50px"></td>
              
              <td>{{ $item->created_at == '' ? 'N/A'  : $item->created_at->format('D-M-Y')  .'('. $item->created_at->diffForHumans() .')'}}</td>
              <td> 
                
               <a target="_blank" class="btn btn-outline-danger" href="{{ url('product') }}/{{ $item->slug }}"><i class="fa fa-street-view"></i></a> 
              <a class="btn btn-outline-success" href="{{ url('/edit-product')}}/{{$item->id }}" ><i class="fa fa-edit"></i></a> 
              <a class="btn btn-outline-danger" href="{{ url('/delete-product')}}/{{$item->id }}"><i class="fa fa-trash"></i></a> 

            </td>
          </tr>
        @endforeach
  </tbody
</table>
{{ $products->links() }}
   
  </div>
</div>
    
  </div>   
 </div> 
</div>
</div>

@endsection
