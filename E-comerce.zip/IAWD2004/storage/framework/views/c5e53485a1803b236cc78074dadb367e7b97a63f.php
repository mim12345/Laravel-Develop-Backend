
<?php $__env->startSection('content'); ?>




    <div class="container-fluid sm-2">
           <div class="col-md-10 offset-1">
               <div class="card-box">
                    <h4 class="header-title mb-4"><STRONG style="color:green;">Add Product</STRONG> </h4>

      <form class="form-horizontal" action="<?php echo e(url('add-product-post')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
             <div class="form-group row">
                 <label for="product_name" class="col-3 col-form-label"><strong>Product Name</strong>
                  </label>
                 <div class="col-9">
                      <input type="text" name="product_name" class="form-control" id="product_name" placeholder=" Product Name">
                  </div>
               </div>
                <div class="form-group row">
                  <label for="subcategory_id" class="col-3 col-form-label"><strong>Category Name</strong>
			      </label>
                   <div class="col-9">
                     <select name="category_id" class="form-control"  id="category_id" >
                         <option value="">Select One</option>
                               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                     </div>
                </div> 

                 <div class="form-group row">
                   <label for="subcategory_id" class="col-3 col-form-label"><strong>Sub Category Name</strong>
					
					</label>
                   <div class="col-9">
                     <select name="subcategory_id" class="form-control"  id="subcategory_id" >
                      <option value="">Select One</option>
                            <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($scat->id); ?>"><?php echo e($scat->subcategory_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                    </div>
                   </div> 
                                          


                 <div class="form-group row">
                    <label for="product_summary" class="col-3 col-form-label">
						<strong>Product Summary</strong>							
					</label>
                    <div class="col-9">
                        <textarea name="product_summary" id="product_summary" class="form-control"></textarea>
                     </div>
                 </div>

                 <div class="form-group row">
                   <label for="product_description" class="col-3 col-form-label"><strong>Product  Description</strong>
				   </label>
                    <div class="col-9">
                    <textarea name="product_description" id="product_description" class="form-control"></textarea>
                    </div>
                 </div>



                  <div class="form-group row">
                   <label for="product_price" class="col-3 col-form-label"><strong>Product Price</strong>								
				  </label>
                    <div class="col-9">
                    <input type="text" name="product_price" class="form-control" id="product_price" placeholder=" Ex:50">
                   </div>
                  </div>

                   <div class="form-group row">
                      <label for="product_quantitiy" class="col-3 col-form-label"><strong>Product Quantity	</strong>
												
		             </label>
                       <div class="col-9">
                           <input type="text" name="product_quantitiy" class="form-control" id="product_quantitiy" placeholder="Ex: 10">
                        </div>
                    </div>                          

                    <div class="form-group row">
                      <label for="product_thumbnail" class="col-3 col-form-label"><strong>Product Thumbnaill</strong>
													
					   </label>
                          <div class="col-9">
                             <input type="File" name="product_thumbnail"  id="product_thumbnail"  onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                           </div> 
                    </div>

                    <div class="form-group row">
                      <label for="" class="col-3 col-form-label"><strong>Product Preview</strong>
						</label>
                          <div class="col-9">
                              <img id="blah" alt="your image" width="100" height="100" />                 
                          </div>
                    </div>

                    
                    <div class="form-group row">
                      <label for="product_gallery" class="col-3 col-form-label"><strong>Image Gallery</strong>
                          
             </label>
                          <div class="col-9">
                             <input type="File" multiple name="product_gallery[]"  id="product_gallery"  onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                           </div> 
                    </div>

                    <div class="form-group mb-0 justify-content-end row">
                                            <div class="col-9">
                                                <button type="submit" class="btn btn-info waves-effect waves-light ">Save</button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                </div>

                 </div>
                                        
                                        
    
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Creative IT php\Laravel\IAWD2004\resources\views/backend/product/product.blade.php ENDPATH**/ ?>