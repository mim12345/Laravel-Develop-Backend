
<?php $__env->startSection('content'); ?>

                        <div class="container-fluid sm-2">
                           <div class="col-md-10 offset-1">
                                <div class="card-box">
                                    <h4 class="header-title mb-4"><STRONG>Add Category</STRONG> </h4>

                                    <form class="form-horizontal" action="<?php echo e(url('add-category-post')); ?>" method="post">
                                      <?php echo csrf_field(); ?>
                                        <div class="form-group row">
                                            <label for="category_name" class="col-3 col-form-label">Category Name</label>
                                            <div class="col-9">
                                                <input type="text" name="category_name" class="form-control" id="category_name" placeholder="Enter your Category Name">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group mb-0 justify-content-end row">
                                            <div class="col-9">
                                                <button type="submit" class="btn btn-info waves-effect waves-light">Save</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
    
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Creative IT php\Laravel\IAWD2004\resources\views/backend/category.blade.php ENDPATH**/ ?>