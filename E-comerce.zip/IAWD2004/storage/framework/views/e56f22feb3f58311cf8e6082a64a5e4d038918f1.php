
<?php $__env->startSection('content'); ?>
<div class="container sm-2">
 <div class="row">
  <div class="col-10 offset-1 ">
    <div class="card bg-light mb-3" style=" margin-top: 50px;">
  <div class="card-header bg-primary text-light  text-center" style="font-family: Times New Roman, Times, serif;"><h4> Sub Category View (Total-<?php echo e($scategory); ?>)</h4></div>
  <div class="card-body">

    <?php if(session('delete')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <strong>Oops!</strong> <?php echo e(session('delete')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <hr>
    <?php endif; ?>
     
     <table class="table table-bordered">
  <thead>
    <tr>
        <th scope="col">SL</th>
        <th scope="col">Sub Category Name</th>
        <th scope="col"> Category Name</th>
        <th scope="col">Created_at</th>
        <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <th scope="row"><?php echo e($categories->firstItem() + $key); ?></th>
              <td><?php echo e($subcategory->subcategory_name ?  : "N/A "); ?></td>
              <td><?php echo e($subcategory->get_category->category_name ?  : "N/A "); ?></td>
              >
              <td><?php echo e($subcategory->created_at == '' ? 'N/A'  : $subcategory->created_at->format('D-M-Y')  .'('. $subcategory->created_at->diffForHumans() .')'); ?></td>
              <td> 
              <a class="btn btn-outline-success" href="<?php echo e(url('/edit-category')); ?>/<?php echo e($subcategory->id); ?>" >Edit</a> 
              <a class="btn btn-outline-danger" href="<?php echo e(url('/delete-subategory')); ?>/<?php echo e($subcategory->id); ?>">Delete</a> 

            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($categories->links()); ?>

   
  </div>
</div>
    
  </div>   
 </div> 
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Creative IT php\Laravel\IAWD2004\resources\views/backend/subcategory/view_subcategory.blade.php ENDPATH**/ ?>