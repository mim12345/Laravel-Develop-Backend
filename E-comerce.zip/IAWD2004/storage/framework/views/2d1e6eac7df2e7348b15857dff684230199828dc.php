

<?php $__env->startSection('content'); ?>

 <!-- .breadcumb-area start -->
    <div class="breadcumb-area bg-img-4 ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb-wrap text-center">
                        <h2>Shopping Cart</h2>
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li><span>Shopping Cart</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .breadcumb-area end -->

    <!-- cart-area start -->
    <div class="cart-area ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-12">

                  <?php if(session('CartDelete')): ?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                      <strong>Oops!</strong> <?php echo e(session('CartDelete')); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <hr>
                   <?php endif; ?>

                    <form action="<?php echo e(route('CartUpdate')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <table class="table-responsive cart-wrap">
                            <thead>
                                <tr>
                                    <th class="images">Image</th>
                                    <th class="product">Product</th>
                                    <th class="ptice">Price</th>
                                    <th class="quantity">Quantity</th>
                                    <th class="total">Total</th>
                                    <th class="remove">Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                     
                                <?php 

                                 $total=0;
                                 $discount=35;

                                ?>

                            	<?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <input type="hidden" value="<?php echo e($cart->id); ?>" name="cart_id[]">
                                <tr>
                                    <td class="images"><img src="<?php echo e(url('img/thumbnail').'/'.$cart->product->product_thumbnail); ?>" alt=""></td>
                                    <td class="product"><a href="single-product.html"><?php echo e($cart->product->product_name); ?></a></td>
                                    <td class="ptice"><?php echo e($cart->product->product_price); ?></td>
                                    <td class="quantity cart-plus-minus">
                                        <input type="text" name="product_quantity[]" value="<?php echo e($cart->product_quantity); ?>" />
                                    </td>
                                    <?php
                                    $total += $cart->product->product_price * $cart->product_quantity
                                    ?>
                                    <td class="total"><?php echo e($cart->product->product_price * $cart->product_quantity); ?> </td>
                                    <td class="remove" data-id="<?php echo e($cart->id); ?>"><a href="#" ><i class="fa fa-times"></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                	<td> Data not Available</td>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                        <div class="row mt-60">
                            <div class="col-xl-4 col-lg-5 col-md-6 ">
                                <div class="cartcoupon-wrap">
                                    <ul class="d-flex">
                                        <li>
                                            <button>Update Cart</button>
                                        </li>
                                        <li><a href="<?php echo e(route('shop')); ?>">Continue Shopping </a></li>
                                    </ul>
                                    <h3>Coupon</h3>
                                    <p>Enter Your Coupon Code if You Have One</p>
                                    <div class="Coupon-wrap">
                                        <input class="CouponValue" value=""  type="text" placeholder="Coupon Code">
                                        <span class="couponbtn">Apply Coupon</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 offset-xl-5 col-lg-4 offset-lg-3 col-md-6">
                                <div class="cart-total text-right">
                                    <h3>Cart Totals</h3>
                                    <ul>
                                        <li><span class="pull-left">Subtotal </span>$<?php echo e($total); ?></li>
                                        
                                        <li><span class="pull-left">Discount(%) </span><?php echo e($discount); ?></li>
                                        
                                          
                                        <li><span class="pull-left"> Total </span> </li>
                                    </ul>
                                    <a href="<?php echo e(route('checkout')); ?>">Proceed to Checkout</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- cart-area end -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_js'); ?>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@9"></script>

<script src="sweetalert2.all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
<script>  

$(document).ready(function () {

 $('.remove').click(function () {
   
   var dataId = $(this).attr("data-id");

    Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.value) {
    
    window.location.href ="<?php echo e(url('/single/cart-delete/')); ?>/"+ dataId;

    Swal.fire(
      'Deleted!',
      'Your file has been deleted.',
      'success'
        )
     }
   })
 })

 $('.couponbtn').click(function () {
   var CouponValue = $('.CouponValue').val();
   window.location.href ="<?php echo e(url('/cart')); ?>/"+ CouponValue;

 })

})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Creative IT php\Laravel\IAWD2004\resources\views/fontend/cart.blade.php ENDPATH**/ ?>