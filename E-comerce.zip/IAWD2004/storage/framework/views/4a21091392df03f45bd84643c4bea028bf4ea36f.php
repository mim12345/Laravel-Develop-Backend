[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH G:\Creative IT php\Laravel\IAWD2004\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>