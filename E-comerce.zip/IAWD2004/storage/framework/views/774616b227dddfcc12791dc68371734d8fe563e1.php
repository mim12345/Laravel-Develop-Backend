
<?php $__env->startSection('content'); ?>
<div class="content">
 <div class="container-fluid ">
 <div class="row">
  <div class="col-12  ">
    <div class="card bg-light mb-3" style=" margin-top: 50px;">
  <div class="card-header bg-primary text-light  text-center" style="font-family: Times New Roman, Times, serif;"><h4> Product View </h4></div>
  <div class="card-body">
    <?php if(session('delete')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <strong>Oops!</strong> <?php echo e(session('delete')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <hr>
    <?php endif; ?>
     
     <table class="table table-bordered">
  <thead>
    <tr>
        <th scope="col">SL</th>
        <th scope="col">Product Name</th>
        <th scope="col"> Category </th>
        
        <th scope="col"> Sub-Category </th>
        <th scope="col"> Price </th>
        <th scope="col"> Quantity </th>
       
       
         <th scope="col"> Image </th>
          <th scope="col">Created_at</th>
        <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <th scope="row"><?php echo e($products->firstItem() + $key); ?></th>
              <td><?php echo e($item->product_name ?  : "N/A "); ?></td>
              <td><?php echo e($item->get_category->category_name); ?></td>
              <td><?php echo e($item->get_subcategory->subcategory_name); ?></td>
              <td><?php echo e($item->product_price); ?></td>
              
              <td><?php echo e($item->product_quantitiy); ?></td>
              <td> <img src="<?php echo e(url('/img/thumbnail/').'/'.$item->product_thumbnail); ?>" width="50px"></td>
              
              <td><?php echo e($item->created_at == '' ? 'N/A'  : $item->created_at->format('D-M-Y')  .'('. $item->created_at->diffForHumans() .')'); ?></td>
              <td> 
                
               <a target="_blank" class="btn btn-outline-danger" href="<?php echo e(url('product')); ?>/<?php echo e($item->slug); ?>"><i class="fa fa-street-view"></i></a> 
              <a class="btn btn-outline-success" href="<?php echo e(url('/edit-product')); ?>/<?php echo e($item->id); ?>" ><i class="fa fa-edit"></i></a> 
              <a class="btn btn-outline-danger" href="<?php echo e(url('/delete-product')); ?>/<?php echo e($item->id); ?>"><i class="fa fa-trash"></i></a> 

            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody
</table>
<?php echo e($products->links()); ?>

   
  </div>
</div>
    
  </div>   
 </div> 
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Creative IT php\Laravel\IAWD2004\resources\views/backend/product/view_product.blade.php ENDPATH**/ ?>