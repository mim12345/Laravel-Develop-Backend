
<h1>Welcome to Admin</h1><?php /**PATH G:\Creative IT php\Laravel\IAWD2004\resources\views/about.blade.php ENDPATH**/ ?>