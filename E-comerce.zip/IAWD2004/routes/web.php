<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Auth Route
Auth::routes(['verify' =>true]);


Route::group(['middleware' => ['auth']], function () {

	//Category Route
	Route::get('/add-category','categorycontroller@category');
	Route::post('/add-category-post','categorycontroller@categorypost');
	Route::get('/view-category-list','categorycontroller@categoryView');
	Route::get('/delete-category/{cat_id}','categorycontroller@categoryDelete');
	Route::get('/edit-category/{cat_id}','categorycontroller@categoryEdit');
	Route::post('/update-category-post','categorycontroller@categoryUpadate');

	//Sub Category Routes
	Route::get('/add-subcategory','Subcategorycontroller@subcategory');
	Route::post('/add-subcategory-post','Subcategorycontroller@subcategorypost');
	Route::get('/view-subcategory-list','Subcategorycontroller@subcategoryView');
	Route::get('/delete-subategory/{cat_id}','Subcategorycontroller@subcategoryDelete');
	Route::get('/edit-subcategory/{cat_id}','Subcategorycontroller@subcategoryEdit');
	Route::post('/update-subcategory-post','Subcategorycontroller@subcategoryUpadate');
	Route::get('/deleted-subategory','Subcategorycontroller@subcategoryDeleted');
	Route::get('/restore-subcategory/{id}','Subcategorycontroller@subcategoryRestore');
	Route::get('/permanent-remove-subcategory/{id}','Subcategorycontroller@subcategoryRemove');

	//Product Route
	Route::get('/add-product','ProductController@product');
	Route::post('/add-product-post','ProductController@productPost');
	Route::get('/view-product-list','ProductController@productView');
	Route::get('/delete-product/{cat_id}','ProductController@productDelete');
	Route::get('/edit-product/{pro_id}','ProductController@productEdit');
	Route::post('/update-product-post','productController@productUpadate')->name('productUpadate');

    // Payment/Dashboard Route     
	
	Route::get('/customer/dashboard', 'CustomerController@index')->name('customerDashboard');
	Route::get('/home', 'HomeController@index')->name('home');
	Route::get('/checkout', 'CheckoutController@checkout')->name('checkout');
	Route::get('/api/get-state-list/{country_id}', 'CheckoutController@GetStateList')->name('GetStateList');
	Route::get('/api/get-city-list/{state_id}', 'CheckoutController@GetCountryList')->name('GetCountryList');
	Route::post('/payment', 'PaymentController@Payment')->name('Payment');
});
    // free use Route
	Route::get('/product/{slug}', 'FontendController@SingleProduct')->name('SingleProduct');
	Route::get('/', 'FontendController@FontendPage')->name('FontendPage');
	Route::get('/shop', 'FontendController@shop')->name('shop');
	Route::get('/single-cart{slug}', 'FontendController@SingleCart')->name('SingleCart');
	Route::get('/cart', 'CartController@cart')->name('cart');
	Route::get('/cart/{coupun}', 'CartController@cart')->name('CouponCart');
	Route::get('/single/cart-delete/{id}', 'CartController@SingleCartDelete')->name('SingleCartDelete');
	Route::post('/cart/update', 'CartController@CartUpdate')->name('CartUpdate');